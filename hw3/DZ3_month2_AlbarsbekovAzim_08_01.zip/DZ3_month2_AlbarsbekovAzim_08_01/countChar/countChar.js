let a = prompt()
function countChar(a) {
    console.log(a.length)
}
countChar(a)
