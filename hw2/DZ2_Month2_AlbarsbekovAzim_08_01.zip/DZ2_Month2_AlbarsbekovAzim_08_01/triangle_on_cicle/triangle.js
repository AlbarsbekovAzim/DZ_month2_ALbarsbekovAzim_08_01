let b = "*"
for (let a = 1; a < 8; a++){
    console.log(b)
    b = b + "*"
}
