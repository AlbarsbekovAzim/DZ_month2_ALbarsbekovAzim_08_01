a=prompt("Введите цвет: ")
switch (a) {
    case "Красный":
        console.log("Остановитесь")
        break
    case "Желтый":
        console.log("Приготовьтесь")
        break
    case "Зелёный":
        console.log("Можете ехать")
        break
    default:
        console.log("Такого цвета нет на светофоре или вы допустили ошибку")
        break
}
