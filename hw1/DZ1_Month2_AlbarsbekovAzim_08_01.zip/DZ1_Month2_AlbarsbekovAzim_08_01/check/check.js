a=[1, 2, 3 ,4, 5, 6, 7]
b=[1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
if (a.length>b.length) {
    console.log("У 1 массива длина больше чем у 2")
}
if (b.length>a.length) {
    console.log("У 2 массива длина больше чем у 1")
}
